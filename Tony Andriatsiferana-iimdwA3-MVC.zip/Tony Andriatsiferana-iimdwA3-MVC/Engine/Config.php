<?php

namespace BlogPhp\Engine;

final class Config
{
    // Identifiants Database
    const
    DB_HOST = 'localhost',
    DB_NAME = 'blog-ecrivain',
    DB_USR = 'root',
    DB_PWD = '',

    // Titre du site
    SITE_NAME = 'Billet simple pour l\'Alaska';
}
