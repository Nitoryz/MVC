


<footer class="page-footer light-blue">
  <div class="footer-copyright">
    <div class="container">
      <div class="row footer-row">
        <div class="col l6 s12">
          Copyright © <?= date("Y"); ?> Jean Forteroche
        </div>
        <div class="col l4 offset-l2 s12">
          <a href="<?=ROOT_URL?>blog_legalNotice.html" class="white-text">Mentions légales</a>
        </div>
      </div>
    </div>
  </div>
</footer>
