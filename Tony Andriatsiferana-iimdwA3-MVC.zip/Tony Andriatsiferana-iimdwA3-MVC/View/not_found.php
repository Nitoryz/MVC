<?php require 'inc/header.php' ?>

<style type="text/css">
  div.vert-align {
    position:absolute;
    left: 50%;
    top: 50%;
    width: 600px;
    height: 200px;
    margin-left: -300px;
    margin-top: -100px;
}
</style>

<div class="center-align vert-align">
  <h1>404 Not Found</h1>

  <p>Le document / fichier demandé n'a pas été trouvé sur ce serveur</p>

  <a href="<?=ROOT_URL?>blog_index.html" class="btn blue waves-effect waves-light">Retourner à l'accueil</a>
</div>
